import sqlite3
from dbconfig import DATABASE_PATH

def init_db():
    with sqlite3.connect(DATABASE_PATH) as conn:
        cursor = conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS customers (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT,
                address TEXT,
                latitude REAL,
                longitude REAL
            )
        ''')
        conn.commit()

def insert_customer(name, address, lat, lng):
    with sqlite3.connect(DATABASE_PATH) as conn:
        cursor = conn.cursor()
        cursor.execute("INSERT INTO customers (name, address, latitude, longitude) VALUES (?, ?, ?, ?)",
                       (name, address, lat, lng))
        conn.commit()

def find_customer(name):
    with sqlite3.connect(DATABASE_PATH) as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM customers WHERE name = ?", (name,))
        return cursor.fetchone()

def update_customer(name, address, lat, lng):
    with sqlite3.connect(DATABASE_PATH) as conn:
        cursor = conn.cursor()
        cursor.execute("UPDATE customers SET address = ?, latitude = ?, longitude = ? WHERE name = ?",
                       (address, lat, lng, name))
        conn.commit()

def delete_customer(name):
    with sqlite3.connect(DATABASE_PATH) as conn:
        cursor = conn.cursor()
        cursor.execute("DELETE FROM customers WHERE name = ?", (name,))
        conn.commit()

def clear_customers():
    with sqlite3.connect(DATABASE_PATH) as conn:
        cursor = conn.cursor()
        cursor.execute('DELETE FROM customers')
        conn.commit()

def get_all_customers():
    with sqlite3.connect(DATABASE_PATH) as conn:
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM customers')
        return cursor.fetchall()
