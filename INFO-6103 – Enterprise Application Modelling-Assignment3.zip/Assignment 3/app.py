import feedparser
from flask import Flask, render_template, request, redirect
import json
import urllib.parse
import urllib.request
from dbhelper import insert_customer, find_customer, update_customer, delete_customer, get_all_customers, clear_customers

app = Flask(__name__)

RSS_FEEDS = {
    'bbc': 'http://feeds.bbci.co.uk/news/rss.xml',
    'cnn': 'http://rss.cnn.com/rss/edition.rss',
    'fox': 'http://feeds.foxnews.com/foxnews/latest',
    'iol': 'http://www.iol.co.za/cmlink/1.640'
}

WEATHER_URL = "http://api.openweathermap.org/data/2.5/weather?q={}&units=metric&appid=d992e1552979f89f5b7ea5449877e1d6"
CURRENCY_URL = "https://openexchangerates.org/api/latest.json?app_id=c4298c3034ed402586336266eefde43e"

DEFAULTS = {
    'publication': 'bbc',
    'city': 'London,UK',
    'currency_from': 'GBP',
    'currency_to': 'USD'
}

@app.route("/clear")
def clear():
    clear_customers()
    return redirect("/")

@app.route("/", methods=["GET", "POST"])
def home():
    message = ""
    customer = {}

    # Handle customer form actions
    if request.method == "POST":
        action = request.form.get("action")
        name = request.form.get("name")
        address = request.form.get("address")
        lat = request.form.get("lat")
        lng = request.form.get("lng")

        if action == "submit":
            insert_customer(name, address, lat, lng)
            message = f"Customer '{name}' added."
        elif action == "find":
            result = find_customer(name)
            if result:
                customer = {
                    "name": result[1],
                    "address": result[2],
                    "lat": result[3],
                    "lng": result[4]
                }
                message = f"Customer '{name}' found."
            else:
                message = f"No customer named '{name}' found."
        elif action == "update":
            update_customer(name, address, lat, lng)
            message = f"Customer '{name}' updated."
        elif action == "delete":
            delete_customer(name)
            message = f"Customer '{name}' deleted."

    # News
    publication = request.args.get('publication') or DEFAULTS['publication']
    articles = get_news(publication)

    # Weather
    city = request.args.get('city') or DEFAULTS['city']
    weather = get_weather(city)

    # Currency
    currency_from = request.args.get("from_currency") or DEFAULTS['currency_from']
    currency_to = request.args.get("to_currency") or DEFAULTS['currency_to']
    amount = request.args.get("amount", 1)

    try:
        amount = float(amount)
    except ValueError:
        amount = 1

    rate, currencies = get_rate(currency_from, currency_to)
    converted_amount = amount * rate

    return render_template("home.html",
        articles=articles,
        weather=weather,
        currency_from=currency_from,
        currency_to=currency_to,
        rate=rate,
        amount=amount,
        converted_amount=converted_amount,
        currencies=sorted(currencies),
        customers=get_all_customers(),
        customer=customer,
        message=message
    )

def get_news(query):
    feed = feedparser.parse(RSS_FEEDS.get(query.lower(), RSS_FEEDS['bbc']))
    return feed['entries']

def get_weather(query):
    query = urllib.parse.quote(query)
    url = WEATHER_URL.format(query)
    data = urllib.request.urlopen(url).read()
    parsed = json.loads(data)
    if parsed.get('weather'):
        return {
            'description': parsed['weather'][0]['description'],
            'temperature': parsed['main']['temp'],
            'city': parsed['name'],
            'country': parsed['sys']['country']
        }
    return None

def get_rate(frm, to):
    data = urllib.request.urlopen(CURRENCY_URL).read()
    rates = json.loads(data).get('rates')
    frm_rate = rates.get(frm.upper())
    to_rate = rates.get(to.upper())
    return (to_rate / frm_rate, rates.keys())

if __name__ == "__main__":
    app.run(port=5000, debug=True)
