# dbconfig.py
DATABASE_PATH = 'customer_data.db'