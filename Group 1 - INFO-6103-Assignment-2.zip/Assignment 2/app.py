import feedparser
from flask import Flask, render_template, request, redirect
from dbhelper import insert_customer, clear_customers, get_all_customers

import json
import urllib.parse
import urllib.request

app = Flask(__name__)

RSS_FEEDS = {
    'bbc': 'http://feeds.bbci.co.uk/news/rss.xml',
    'cnn': 'http://rss.cnn.com/rss/edition.rss',
    'fox': 'http://feeds.foxnews.com/foxnews/latest',
    'iol': 'http://www.iol.co.za/cmlink/1.640'
}

WEATHER_URL = "http://api.openweathermap.org/data/2.5/weather?q={}&units=metric&appid=d992e1552979f89f5b7ea5449877e1d6"
CURRENCY_URL = "https://openexchangerates.org//api/latest.json?app_id=c4298c3034ed402586336266eefde43e"

DEFAULTS = {
    'publication': 'bbc',
    'city': 'London,UK',
    'currency_from': 'GBP',
    'currency_to': 'USD'
}

@app.route("/clear")
def clear():
    clear_customers()
    return redirect("/")

@app.route("/", methods=["GET", "POST"])
def home():
    # POST: insert name and redirect with name as query param
    if request.method == "POST":
        name = request.form.get("customer_name")
        if name:
            insert_customer(name)
        return redirect(f"/?submitted_name={urllib.parse.quote(name)}")

    # GET: handle inputs from URL
    submitted_name = request.args.get("submitted_name")

    publication = request.args.get('publication') or DEFAULTS['publication']
    articles = get_news(publication)

    city = request.args.get('city') or DEFAULTS['city']
    weather = get_weather(city)

    currency_from = request.args.get("from_currency") or DEFAULTS['currency_from']
    currency_to = request.args.get("to_currency") or DEFAULTS['currency_to']
    amount = request.args.get("amount", 1)

    try:
        amount = float(amount)
    except ValueError:
        amount = 1

    rate, currencies = get_rate(currency_from, currency_to)
    converted_amount = amount * rate



    return render_template("home.html",
        customer_name=submitted_name,
        customers=get_all_customers(),
        articles=articles,
        weather=weather,
        currency_from=currency_from,
        currency_to=currency_to,
        rate=rate,
        amount=amount,
        converted_amount=converted_amount,
        currencies=sorted(currencies)
    )


def get_news(query):
    publication = query.lower() if query and query.lower() in RSS_FEEDS else DEFAULTS["publication"]
    feed = feedparser.parse(RSS_FEEDS[publication])
    return feed['entries']

def get_weather(query):
    query = urllib.parse.quote(query)
    url = WEATHER_URL.format(query)
    data = urllib.request.urlopen(url).read()
    parsed = json.loads(data)
    weather = None
    if parsed.get('weather'):
        weather = {
            'description': parsed['weather'][0]['description'],
            'temperature': parsed['main']['temp'],
            'city': parsed['name'],
            'country': parsed['sys']['country']
        }
    return weather

def get_rate(frm, to):
    all_currency = urllib.request.urlopen(CURRENCY_URL).read()
    parsed = json.loads(all_currency).get('rates')
    frm_rate = parsed.get(frm.upper())
    to_rate = parsed.get(to.upper())
    return (to_rate / frm_rate, parsed.keys())

if __name__ == "__main__":
    app.run(port=5000, debug=True)
