# init_db.py
from dbhelper import init_db

init_db()
print("Database initialized.")
